//
//  MPTextView.h
//  DataURLMaker
//
//  Created by Sveinbjorn Thordarson on 11/30/05.
//  Copyright 2005 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSTextView (MPDrag)
{

}

@end
