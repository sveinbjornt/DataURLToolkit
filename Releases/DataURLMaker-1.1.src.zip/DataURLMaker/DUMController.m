/*
    DataURLMaker
    Copyright (C) 2006-2008 Sveinbjorn Thordarson <sveinbjornt@simnet.is>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

#import "DUMController.h"
#import <WebKit/WebKit.h>

@implementation DUMController

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	[window center];
	[window makeKeyAndOrderFront: self];
	[textField setFont:[NSFont userFixedPitchFontOfSize: 10.0]];
	[window registerForDraggedTypes: [NSArray arrayWithObjects:NSFilenamesPboardType, nil]];
}

/*****************************************
 - Handler for dragged files and/or files opened via the Finder
*****************************************/

- (BOOL)application:(NSApplication *)theApplication openFile:(NSString *)filename
{
	BOOL	isDir = NO;
	
	if([[NSFileManager defaultManager] fileExistsAtPath: filename isDirectory: &isDir] && !isDir)
	{
		[self loadFile: filename];
		return(YES);
	}
	return(NO);
}


- (IBAction)selectImage:(id)sender
{
	NSOpenPanel *oPanel = [NSOpenPanel openPanel];
	[oPanel setPrompt:@"Select"];
    [oPanel setAllowsMultipleSelection:NO];
	[oPanel setCanChooseDirectories: NO];
	
	//run open panel
    [oPanel beginSheetForDirectory: nil file:nil types:nil modalForWindow: window 
		             modalDelegate: self didEndSelector: @selector(selectImageDidEnd:returnCode:contextInfo:) contextInfo: nil];
}

- (void)selectImageDidEnd:(NSOpenPanel *)oPanel returnCode:(int)returnCode contextInfo:(void *)contextInfo
{
	if (returnCode != NSOKButton)
		return;
	
	[self loadFile: [oPanel filename]];	
}

- (void)loadFile: (NSString *)path
{
	NSImage *theImage = [[[NSImage alloc] initByReferencingFile: path] autorelease];
	NSSize imgSize = [theImage size];
	int width=imgSize.width;
	int height=imgSize.height;
	
	NSString *dimensionsString = [NSString stringWithFormat: @"%d x %d", width, height];
	
	NSData *imgData = [NSData dataWithContentsOfFile: path];
	if (imgData == NULL)
	{
		[STUtil sheetAlert: @"Error loading image" subText: @"An error occurred when loading data from the image file you selected" forWindow: window];
		return;
	}
	
	//create img tag
	NSString *data64string = [imgData base64EncodingWithLineLength: 0];
	NSString *dataURLstring = [NSString stringWithFormat: @"<img width=\"%d\" height=\"%d\" src=\"data:image/%@;base64,%@\">", width, height, [path pathExtension], data64string];

	//load with webview
	[[webView mainFrame] loadHTMLString: dataURLstring baseURL: NULL]; 

	// set text in fields
	[textField setString: dataURLstring];
	[lengthField setStringValue: [NSString stringWithFormat: @"Data URL Size: %@ (%d bytes)", [STUtil sizeAsHumanReadable: [data64string length]], [data64string length]]]; 
	[pathField setStringValue: path];
	[dimensionsField setStringValue: dimensionsString];
	[imgSizeField setStringValue: [NSString stringWithFormat: @"%@ (%d bytes)", [STUtil fileOrFolderSizeAsHumanReadable: path], [STUtil fileOrFolderSize: path]]];
}

- (IBAction)clear:(id)sender;
{
	[textField setString: @""];
	[lengthField setStringValue: @""];
	[pathField setStringValue: @""];
	[imgSizeField setStringValue: @""];
	[dimensionsField setStringValue: @""];
	[[webView mainFrame] loadHTMLString: @"" baseURL: NULL]; 
}

- (IBAction)export:(id)sender
{
	NSString *name = [NSString stringWithFormat: @"%@.html", [[pathField stringValue] lastPathComponent]];

	NSSavePanel *sPanel = [NSSavePanel savePanel];
	[sPanel setPrompt:@"Save"];
	[sPanel beginSheetForDirectory: nil file: name modalForWindow: window modalDelegate: self didEndSelector: @selector(exportConfirmed:returnCode:contextInfo:) contextInfo: nil];
}

- (void)exportConfirmed:(NSSavePanel *)sPanel returnCode:(int)result contextInfo:(void *)contextInfo
{
	if (result != NSOKButton) 
		return;
		
	[[textField string] writeToFile: [sPanel filename] atomically: YES];
}

- (IBAction)copyToClipboard:(id)sender
{
	NSLog(@"Copying");
	[[NSPasteboard generalPasteboard] declareTypes: [NSArray arrayWithObject: NSStringPboardType] owner: self];
	[[NSPasteboard generalPasteboard] setString: [textField string] forType: NSStringPboardType];
}

/*****************************************
 - Dragging and dropping for window
*****************************************/

- (BOOL)performDragOperation:(id <NSDraggingInfo>)sender
{
	NSPasteboard	*pboard = [sender draggingPasteboard];
	NSString		*filename;
	BOOL			isDir = FALSE;

    if ( [[pboard types] containsObject:NSFilenamesPboardType] ) 
	{
        NSArray *files = [pboard propertyListForType:NSFilenamesPboardType];
		filename = [files objectAtIndex: 0];//we only load the first dragged item
		if ([[NSFileManager defaultManager] fileExistsAtPath: filename isDirectory:&isDir] && !isDir)
		{
			[self loadFile: filename];
			return YES;
		}
	}
	return NO;
}


- (NSDragOperation)draggingEntered:(id <NSDraggingInfo>)sender 
{

    NSPasteboard *pboard;
    NSDragOperation sourceDragMask;

    sourceDragMask = [sender draggingSourceOperationMask];
    pboard = [sender draggingPasteboard];


    if ( [[pboard types] containsObject:NSFilenamesPboardType] ) 
	{
        if (sourceDragMask & NSDragOperationLink) 
            return NSDragOperationLink;
		else if (sourceDragMask & NSDragOperationCopy)
            return NSDragOperationCopy;
    }

    return NSDragOperationNone;
}

@end

