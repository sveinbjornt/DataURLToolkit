/* DUMController */

#import <Cocoa/Cocoa.h>
#import "GSNSDataExtensions.h"
#import "STUtil.h"

@interface DUMController : NSObject
{
    IBOutlet id textField;
	IBOutlet id pathField;
	IBOutlet id lengthField;
    IBOutlet id webView;
	IBOutlet id window;
	IBOutlet id exportButton;
}
- (IBAction)selectImage:(id)sender;
@end
