#import "DUMController.h"
#import <WebKit/WebKit.h>

@implementation DUMController

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	[textField setFont:[NSFont userFixedPitchFontOfSize: 10.0]];
}

- (IBAction)selectImage:(id)sender
{
	NSOpenPanel *oPanel = [NSOpenPanel openPanel];
	[oPanel setPrompt:@"Select"];
    [oPanel setAllowsMultipleSelection:NO];
	[oPanel setCanChooseDirectories: NO];
	
	//run open panel
    [oPanel beginSheetForDirectory: nil file:nil types:nil modalForWindow: window 
		             modalDelegate: self didEndSelector: @selector(selectImageDidEnd:returnCode:contextInfo:) contextInfo: nil];
}

- (void)selectImageDidEnd:(NSOpenPanel *)oPanel returnCode:(int)returnCode contextInfo:(void *)contextInfo
{
	if (returnCode != NSOKButton)
		return;
	
	NSString *path = [oPanel filename];

	NSData *imgData = [NSData dataWithContentsOfFile: path];
	if (imgData == NULL)
	{
		[STUtil sheetAlert: @"Error loading image" subText: @"An error occurred when loading data from the image file you selected" forWindow: window];
		return;
	}
	
	//create img tag
	NSString *data64string = [imgData base64EncodingWithLineLength: 0];
	NSString *dataURLstring = [NSString stringWithFormat: @"<img src=\"data:image/%@;base64,%@\">", [path pathExtension], data64string];

	//load with webview
	[[webView mainFrame] loadHTMLString: dataURLstring baseURL: NULL]; 

	// set text in fields
	[textField setString: dataURLstring];
	[lengthField setStringValue: [NSString stringWithFormat: @"Data Length: %d characters", [dataURLstring length]]]; 
	[pathField setStringValue: path];
	
	//make sure export button is enabled
	[exportButton setEnabled: YES];
}

- (IBAction)export:(id)sender
{
	NSString *name = [NSString stringWithFormat: @"%@.html", [[pathField stringValue] lastPathComponent]];

	NSSavePanel *sPanel = [NSSavePanel savePanel];
	[sPanel setPrompt:@"Save"];
	[sPanel beginSheetForDirectory: nil file: name modalForWindow: window modalDelegate: self didEndSelector: @selector(exportConfirmed:returnCode:contextInfo:) contextInfo: nil];
}

- (void)exportConfirmed:(NSSavePanel *)sPanel returnCode:(int)result contextInfo:(void *)contextInfo
{
	if (result != NSOKButton) 
		return;
		
	[[textField string] writeToFile: [sPanel filename] atomically: YES];
}
@end

